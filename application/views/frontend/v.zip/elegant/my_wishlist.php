<div id="wishlist_items">
  <?php include 'wishlist_items.php'; ?>
</div>
