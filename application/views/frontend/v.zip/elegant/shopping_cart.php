<div id="cart_items">
  <?php include 'cart_items.php'; ?>
</div>
